//base패키지의 Shape class, derived 패키지의 Circle class 가져옴.
package app;
import base.Shape;
import derived.Circle;

public class GraphicEditor extends Circle {
	public static void main(String[] args) {
		Shape shape = new Circle();
		shape.draw();
	}
}
