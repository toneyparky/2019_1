//원의 중심과 반지름을 저장, 중심이 같은지 알아보는 메서드 equals().
import java.lang.String;

public class Circle {
	
	int x, y, radius;
	
	public Circle(int a, int b, int c) {
		this.x = a;
		this.y = b;
		this.radius = c;
		
		
	}

	public String toString() {
		
		return "Circle(" + this.x + "," + this.y + ") 반지름" + this.radius;
	}
	
	public boolean equals(Circle circle) {
		boolean result;
		if(this.x == circle.x && this.y == circle.y)
			result = true;
		else
			result = false;
		
		return result;
	}
	
}
