//base패키지의 Shape class가져옴.  
package derived;
import base.Shape;

public class Circle extends Shape {
	public void draw() { System.out.println("Circle"); }
}
