//공백으로 분리된 단어(word)가 몇 개가 들어 있는지 그리고 단어를 각라인에 출력하라. 프로그램은 “exit”을 입력할 때까지 반복한다. 
//StringTokenizer를 사용. 
import java.util.Scanner;
import java.util.StringTokenizer;
import java.lang.String;

public class token {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		
		while(true) {
			String sentence = input.nextLine();
			StringTokenizer words = new StringTokenizer(sentence, " ");
			//탈출조건 
			if(sentence.equals("exit")) {
				System.out.println("종료합니다.");
				break;
			}
			
			//단어 개수 출력 
			System.out.println("단어 개수는 " + words.countTokens());		
			
			while(words.hasMoreTokens()) {
				System.out.println(words.nextToken());
				
			}
			
		}
			
	}

}
