//공백으로 분리된 단어(word)가 몇 개가 들어 있는지 그리고 단어를 각라인에 출력하라. 프로그램은 “exit”을 입력할 때까지 반복한다. 
//String 클래스의 split() 메서드를 사용. 
import java.lang.String;
import java.util.Scanner;


public class Split {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		while(true) {
			String sentence = input.nextLine();
			
			//탈출조건 
			if(sentence.equals("exit")) {
				System.out.println("종료합니다.");
				break;
			}
			
			String word[] = sentence.split(" ");
			//단어 개수 출력 
			System.out.println("단어 개수는 " + word.length);	
			for(int i = 0; i<word.length; i++) {
				System.out.println(word[i]);
			}
			
		}
		
	}

}
