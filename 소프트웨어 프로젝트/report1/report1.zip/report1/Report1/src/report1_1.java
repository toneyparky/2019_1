//작은 w를 이용하여 큰 www를 출력하는 프로그램.
//2019.03.21.목
//소프트웨어 프로젝트 수업 과제 1-1

public class report1_1 {

	public static void main(String[] args) {

				System.out.println("w             ww             ww             w");
				System.out.println(" w     w     w  w     w     w  w     w     w");
				System.out.println("  w   w w   w    w   w w   w    w   w w   w");
				System.out.println("   w w   w w      w w   w w      w w   w w");
				System.out.println("    w     w        w     w        w     w");
		
	}
}